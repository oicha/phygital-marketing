<?php

include_once 'lib/mkd-instagram-api.php';
include_once 'widgets/load.php';